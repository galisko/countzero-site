# Notice

This package is an independent security research laboratory built around the
Microsoft Agent Governance Toolkit public-preview ecosystem. Microsoft and
GitHub are trademarks of their respective owners. Review the licenses of all
upstream dependencies before redistribution or commercial use.

The included examples are provided without warranty and are intended for
controlled educational and evaluation environments only.
