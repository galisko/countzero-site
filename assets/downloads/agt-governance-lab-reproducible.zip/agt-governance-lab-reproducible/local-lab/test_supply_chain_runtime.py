from pathlib import Path

from agent_os.integrations.base import BaseIntegration, ExecutionContext, GovernancePolicy


class TestIntegration(BaseIntegration):
    def wrap(self, fn):
        return fn

    def unwrap(self, fn):
        return fn


fixture = Path(__file__).parent / "test-fixtures" / "supply-chain"
policy = GovernancePolicy(
    name="supply-chain-test",
    supply_chain={"enabled": True, "freshness_days": 7, "allow_ranges": False},
)
integration = TestIntegration(policy=policy)
context = ExecutionContext("copilot", "supply-chain-test", policy)

print("=" * 72)
print("TEST 13 - SUPPLY CHAIN GUARD")
print("=" * 72)
result = integration.pre_execute_check(
    context,
    {"tool_name": "dependency_scan", "supply_chain_path": str(fixture)},
)
print(result)
print(f"ALLOWED: {result.allowed}")
print(f"REASON: {result.reason}")
