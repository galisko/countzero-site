from agent_os.integrations.base import (
    BaseIntegration,
    BoundedSemaphore,
    ContentHashInterceptor,
    ExecutionContext,
    GovernancePolicy,
    PatternType,
    ToolCallRequest,
)


class TestIntegration(BaseIntegration):
    def wrap(self, fn):
        return fn

    def unwrap(self, fn):
        return fn


def heading(name):
    print("\n" + "=" * 72)
    print(name)
    print("=" * 72)


def decision(label, result):
    print(f"{label}: allowed={result.allowed} reason={result.reason!r}")


heading("TEST 7 - COMMAND EXECUTION GOVERNANCE (SIMULATION ONLY)")
default_policy = GovernancePolicy(name="command-default")
default_agt = TestIntegration(policy=default_policy)
default_ctx = ExecutionContext("copilot", "command-default", default_policy)
decision(
    "DEFAULT rm -rf",
    default_agt.pre_execute_check(
        default_ctx, {"tool_name": "shell", "command": "rm -rf /tmp/agt-fake-target"}
    ),
)

blocked_policy = GovernancePolicy(
    name="command-blocked",
    blocked_patterns=[
        (r"rm\s+-rf", PatternType.REGEX),
        (r"curl\s+.*https?://", PatternType.REGEX),
    ],
)
blocked_agt = TestIntegration(policy=blocked_policy)
blocked_ctx = ExecutionContext("copilot", "command-blocked", blocked_policy)
decision(
    "CONFIGURED rm -rf",
    blocked_agt.pre_execute_check(
        blocked_ctx, {"tool_name": "shell", "command": "rm -rf /tmp/agt-fake-target"}
    ),
)
decision(
    "CONFIGURED curl",
    blocked_agt.pre_execute_check(
        blocked_ctx, {"tool_name": "shell", "command": "curl https://example.invalid/upload"}
    ),
)


heading("TEST 8 - CONTENT HASH / TOOL IDENTITY")
expected_hash = "a" * 64
hash_guard = ContentHashInterceptor({"read_file": expected_hash}, strict=True)
for label, tool, metadata in [
    ("MATCH", "read_file", {"content_hash": expected_hash}),
    ("MISMATCH", "read_file", {"content_hash": "b" * 64}),
    ("MISSING METADATA", "read_file", {}),
    ("UNKNOWN TOOL", "wrapped_read_file", {"content_hash": expected_hash}),
]:
    request = ToolCallRequest(tool_name=tool, arguments={}, metadata=metadata)
    decision(label, hash_guard.intercept(request))


heading("TEST 9 - RATE LIMITER")
rate_policy = GovernancePolicy(
    name="rate-limit",
    rate_limiter={"enabled": True, "max_calls": 2, "time_window": 60, "per_agent": True},
)
rate_agt = TestIntegration(policy=rate_policy)
rate_ctx = ExecutionContext("copilot", "rate-limit", rate_policy)
for number in range(1, 4):
    decision(
        f"CALL {number}",
        rate_agt.pre_execute_check(rate_ctx, {"tool_name": "read_file", "path": "fake.txt"}),
    )


heading("TEST 10 - TOKEN BUDGET")
token_policy = GovernancePolicy(
    name="token-budget",
    max_tokens=100,
    token_budget={"enabled": True, "warning_threshold": 0.8},
)
token_agt = TestIntegration(policy=token_policy)
token_ctx = ExecutionContext("copilot", "token-budget", token_policy)
for label, amount in [("USAGE 60", 60), ("CUMULATIVE 110", 50)]:
    decision(
        label,
        token_agt.pre_execute_check(
            token_ctx, {"tool_name": "llm", "prompt_tokens": amount, "completion_tokens": 0}
        ),
    )


heading("TEST 11 - BOUNDED CONCURRENCY PRIMITIVE")
semaphore = BoundedSemaphore(max_concurrent=2, backpressure_threshold=1)
for number in range(1, 4):
    acquired, reason = semaphore.try_acquire()
    print(
        f"ACQUIRE {number}: acquired={acquired} reason={reason!r} "
        f"active={semaphore.active} pressure={semaphore.is_under_pressure}"
    )
semaphore.release()
print(f"AFTER RELEASE: {semaphore.stats()}")


heading("TEST 12 - OPTIONAL SUPPLY CHAIN MODULE AVAILABILITY")
try:
    import agent_compliance.supply_chain  # noqa: F401
except ImportError as exc:
    print(f"AVAILABLE=False reason={exc}")
else:
    print("AVAILABLE=True")
