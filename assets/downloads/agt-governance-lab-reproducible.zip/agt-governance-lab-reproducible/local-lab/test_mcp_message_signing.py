from agent_os.mcp_message_signer import MCPMessageSigner
from dataclasses import replace


print("=" * 60)
print("INITIALIZE SIGNER")
print("=" * 60)

key = MCPMessageSigner.generate_key()

signer = MCPMessageSigner(
    signing_key=key
)


print("=" * 60)
print("CREATE SIGNED MESSAGE")
print("=" * 60)

envelope = signer.sign_message(
    payload='{"tool":"read_file","path":"/tmp/test.txt"}',
    sender_id="copilot-agent"
)

print(envelope)


print("=" * 60)
print("VALID MESSAGE")
print("=" * 60)

result = signer.verify_message(envelope)

print(result)


print("=" * 60)
print("TAMPERED MESSAGE")
print("=" * 60)

tampered = replace(
    envelope,
    payload='{"tool":"delete_file","path":"/tmp/test.txt"}',
    nonce="different_nonce_12345"
)

result = signer.verify_message(tampered)

print(result)


print("=" * 60)
print("REPLAY ORIGINAL MESSAGE")
print("=" * 60)

result = signer.verify_message(envelope)

print(result)