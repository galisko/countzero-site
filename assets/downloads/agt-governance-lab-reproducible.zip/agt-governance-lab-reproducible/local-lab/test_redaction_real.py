from agent_os.credential_redactor import CredentialRedactor


tests = [
    "password=SuperSecret123",
    '{"password":"SuperSecret123"}',
    "api_key=abc123456789",
    "Bearer eyJhbGciOiJIUzI1NiJ9.test.payload",
    "-----BEGIN PRIVATE KEY-----\nABCDEF\n-----END PRIVATE KEY-----",
    "AKIA1234567890ABCDEF",
    "normal text no secret"
]


for t in tests:
    print("="*60)
    print("INPUT:")
    print(t)
    print("\nOUTPUT:")
    print(CredentialRedactor.redact(t))