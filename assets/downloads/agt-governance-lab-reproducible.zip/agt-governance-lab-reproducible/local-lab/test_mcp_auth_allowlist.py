from agent_os.mcp_auth_enforcement import (
    McpAuthPolicy,
    McpServerEntry,
)


policy = McpAuthPolicy(
    servers=[
        McpServerEntry(
            name="finance-tools",
            url="https://mcp.internal.finance",
            allowed_auth_methods=["mtls"],
            require_tls=True,
        )
    ]
)


tests = [
    ("finance-tools", "mtls", "https://mcp.internal.finance"),
    ("finance-tools", "bearer", "https://mcp.internal.finance"),
    ("finance-tools", "mtls", "http://mcp.internal.finance"),
]


for server, auth, url in tests:
    print("=" * 60)
    result = policy.check(
        server_name=server,
        auth_method=auth,
        url=url,
    )

    print("Server:", server)
    print("Auth:", auth)
    print("URL:", url)
    print("Allowed:", result.allowed)
    print("Reason:", result.reason)