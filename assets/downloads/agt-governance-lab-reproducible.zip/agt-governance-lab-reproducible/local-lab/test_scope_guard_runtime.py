from agent_os.integrations.base import (
    BaseIntegration,
    GovernancePolicy,
    ExecutionContext,
)


class TestIntegration(BaseIntegration):

    def wrap(self, fn):
        return fn

    def unwrap(self, fn):
        return fn


print("="*70)
print("AGT SCOPE GUARD TEST")
print("="*70)


policy = GovernancePolicy(
    name="scope-test",

    scope_guard={
        "enabled": True,
        "max_files": 2,
        "max_lines": 10,
        "mode": "on",
        "drift_detection": True,
    }
)


agt = TestIntegration(policy=policy)


ctx = ExecutionContext(
    agent_id="copilot",
    session_id="scope-test",
    policy=policy,
)


tests = [

{
"name":"SMALL CHANGE",
"input":{
"changed_files":[
"app.py"
],
"insertions":5,
"deletions":1
}
},


{
"name":"LARGE CHANGE",
"input":{
"changed_files":[
"a.py",
"b.py",
"c.py"
],
"insertions":100,
"deletions":20
}
}

]


for t in tests:

    print("\n")
    print("="*70)
    print(t["name"])
    print("="*70)

    result = agt.pre_execute_check(
        ctx,
        t["input"]
    )

    print(result)

    print("ALLOWED:", result.allowed)
    print("REASON:", result.reason)