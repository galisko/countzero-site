from agent_os.mcp_gateway import MCPGateway
from agent_os.integrations.base import GovernancePolicy
from agent_os.mcp_protocols import MCPAuditSink


class FileAuditSink:
    def __init__(self):
        self.events = []

    def record(self, entry):
        self.events.append(entry)
        print("AUDIT EVENT:")
        print(entry)


policy = GovernancePolicy(
    name="audit-test",
    max_tool_calls=2,
    log_all_calls=True
)


sink = FileAuditSink()


gateway = MCPGateway(
    policy,
    audit_sink=sink
)


print("="*60)
print("ALLOWED CALL")
print("="*60)


gateway.intercept_tool_call(
    "copilot",
    "read_file",
    {
        "path": "/tmp/test.txt",
        "password": "FAKE_SECRET_123"
    }
)


print("="*60)
print("BLOCKED CALL")
print("="*60)


gateway.intercept_tool_call(
    "copilot",
    "read_file",
    {
        "path": "/tmp/.env"
    }
)


print("="*60)
print("TOTAL EVENTS")
print("="*60)

print(len(sink.events))