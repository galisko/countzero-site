from agent_os.integrations.base import (
    BaseIntegration,
    GovernancePolicy,
    ExecutionContext,
)


class TestIntegration(BaseIntegration):

    def wrap(self, fn):
        return fn

    def unwrap(self, fn):
        return fn


print("=" * 70)
print("AGT FILE ACCESS GOVERNANCE TEST")
print("=" * 70)


policy = GovernancePolicy(
    name="file-access-test",
    max_tool_calls=5,
)


agt = TestIntegration(policy=policy)


ctx = ExecutionContext(
    agent_id="copilot",
    session_id="file-test",
    policy=policy,
)


tests = [
    {
        "name": "NORMAL FILE",
        "input": {
            "tool_name": "read_file",
            "path": "/Users/nowi/AGT-Lab/workspace/test.txt"
        }
    },
    {
        "name": "FAKE SECRET FILE",
        "input": {
            "tool_name": "read_file",
            "path": "/Users/nowi/AGT-Lab/test-secrets/fake_id_rsa"
        }
    },
]


for test in tests:

    print("\n")
    print("=" * 70)
    print(test["name"])
    print("=" * 70)

    result = agt.pre_execute_check(
        ctx,
        test["input"]
    )

    print(result)

    print("\nALLOWED:")
    print(result.allowed)

    print("\nREASON:")
    print(result.reason)
