from agent_os.mcp_gateway import MCPGateway
from agent_os.integrations.base import GovernancePolicy


policy = GovernancePolicy(
    name="allowlist-test",
    allowed_tools=[
        "read_file"
    ]
)

gateway = MCPGateway(
    policy=policy
)


print("="*60)
print("TOOL ALLOWLIST TEST")
print("="*60)


tests = [
    {
        "tool": "read_file",
        "params": {
            "path": "/tmp/test.txt"
        }
    },
    {
        "tool": "delete_file",
        "params": {
            "path": "/tmp/test.txt"
        }
    }
]


for t in tests:

    result = gateway.intercept_tool_call(
        agent_id="copilot",
        tool_name=t["tool"],
        params=t["params"]
    )

    print()
    print("TOOL:", t["tool"])
    print("RESULT:")
    print(result)


print()
print("="*60)
print("AUDIT LOG")
print("="*60)

for entry in gateway.audit_log:
    print(entry)