from agent_os.integrations.base import (
    BaseIntegration,
    GovernancePolicy,
    ExecutionContext,
)


class TestIntegration(BaseIntegration):

    def wrap(self, fn):
        return fn

    def unwrap(self, fn):
        return fn


print("=" * 70)
print("AGT PATH TRAVERSAL TEST")
print("=" * 70)


policy = GovernancePolicy(
    name="path-test",
    max_tool_calls=10,
)


agt = TestIntegration(policy=policy)


ctx = ExecutionContext(
    agent_id="copilot",
    session_id="path-test",
    policy=policy,
)


tests = [

    {
        "name": "WORKSPACE FILE",
        "input": {
            "tool_name": "read_file",
            "path": "/Users/nowi/AGT-Lab/workspace/test.txt"
        }
    },

    {
        "name": "RELATIVE ESCAPE",
        "input": {
            "tool_name": "read_file",
            "path": "../../.ssh/id_rsa"
        }
    },

    {
        "name": "ABSOLUTE SSH KEY",
        "input": {
            "tool_name": "read_file",
            "path": "/Users/nowi/.ssh/id_rsa"
        }
    },

    {
        "name": "SYSTEM FILE",
        "input": {
            "tool_name": "read_file",
            "path": "/etc/passwd"
        }
    },
]


for test in tests:

    print("\n")
    print("=" * 70)
    print(test["name"])
    print("=" * 70)

    result = agt.pre_execute_check(
        ctx,
        test["input"]
    )

    print(result)

    print("ALLOWED:", result.allowed)
    print("REASON:", result.reason)
