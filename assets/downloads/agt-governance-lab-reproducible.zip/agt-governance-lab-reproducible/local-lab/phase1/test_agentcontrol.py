import asyncio

from agent_control_specification import AgentControl


async def delete_file(args):
    print(">>> REAL DELETE EXECUTED")
    return {
        "status": "deleted",
        "file": args["path"]
    }


async def read_file(args):
    print(">>> REAL READ EXECUTED")
    return {
        "content": "lab data"
    }


async def main():

    control = AgentControl.from_path(
        "policy.yaml"
    )

    protected_delete = control.protect_tool(
        "delete_file",
        delete_file
    )

    protected_read = control.protect_tool(
        "read_file",
        read_file
    )


    print("\n=== DELETE TEST ===")

    try:
        result = await protected_delete(
            {
                "path": "/tmp/test.txt"
            }
        )

        print(result)

    except Exception as e:
        print("BLOCKED:")
        print(type(e).__name__)
        print(e)



    print("\n=== READ TEST ===")

    try:
        result = await protected_read(
            {}
        )

        print(result)

    except Exception as e:
        print("BLOCKED:")
        print(type(e).__name__)
        print(e)



asyncio.run(main())