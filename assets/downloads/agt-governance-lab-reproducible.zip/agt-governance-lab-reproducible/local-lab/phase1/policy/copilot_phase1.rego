package copilot_phase1

import rego.v1

default verdict := {"decision": "allow"}

verdict := {
	"decision": "deny",
	"reason": "destructive_delete_blocked",
	"message": "delete_file is blocked by the Phase 1 policy.",
} if {
	input.tool.name == "delete_file"
}
