package agt

default allow = false

allow {
    input.tool_call.name == "read_file"
}