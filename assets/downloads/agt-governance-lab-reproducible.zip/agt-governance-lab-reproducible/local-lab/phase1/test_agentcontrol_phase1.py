import asyncio

from agent_control_specification import AgentControl, AgentControlBlocked


executed = []


async def delete_file(args):
    executed.append(("delete_file", args))
    return {"status": "deleted", "file": args["path"]}


async def read_file(args):
    executed.append(("read_file", args))
    return {"content": "lab data"}


async def main():
    control = AgentControl.from_path("manifest.yaml")

    for name, function, arguments in (
        ("delete_file", delete_file, {"path": "/tmp/agt-phase1-fake.txt"}),
        ("read_file", read_file, {}),
    ):
        try:
            result = await control.run_tool(name, arguments, function)
            print(f"{name}: {result.pre_tool_call_result.verdict.decision.value}")
            print(f"{name}_executed: {any(item[0] == name for item in executed)}")
        except AgentControlBlocked as error:
            print(f"{name}: {error.result.verdict.decision.value}")
            print(f"{name}_reason: {error.result.verdict.reason}")
            print(f"{name}_executed: {any(item[0] == name for item in executed)}")


asyncio.run(main())
