from agent_os.mcp_gateway import MCPGateway
from agent_os.integrations.base import GovernancePolicy


policy = GovernancePolicy(
    name="rate-limit-test",
    max_tool_calls=3,
    log_all_calls=True
)


gateway = MCPGateway(policy)


print("=" * 70)
print("TEST MAX TOOL CALLS")
print("=" * 70)


for i in range(1, 6):

    allowed, reason = gateway.intercept_tool_call(
        "copilot",
        "read_file",
        {
            "path": f"/tmp/test-{i}.txt"
        }
    )

    print(
        f"CALL {i}: allowed={allowed} reason={reason}"
    )


print()
print("=" * 70)
print("AUDIT LOG")
print("=" * 70)

for event in gateway.audit_log:
    print(event)