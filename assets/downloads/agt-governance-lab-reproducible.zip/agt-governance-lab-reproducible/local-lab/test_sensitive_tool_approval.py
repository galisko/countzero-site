from agent_os.mcp_gateway import MCPGateway
from agent_os.integrations.base import GovernancePolicy
from agent_os.mcp_gateway import ApprovalStatus

policy = GovernancePolicy(
    name="approval-test",
    max_tool_calls=10
)


def approval_callback(agent_id, tool_name, params):
    print("APPROVAL REQUEST:")
    print("agent:", agent_id)
    print("tool:", tool_name)
    print("params:", params)

    return ApprovalStatus.DENIED


gateway = MCPGateway(
    policy=policy,
    sensitive_tools=[
        "delete_file"
    ],
    approval_callback=approval_callback
)


print("="*60)
print("NORMAL TOOL")
print("="*60)

print(
    gateway.intercept_tool_call(
        "copilot",
        "read_file",
        {
            "path":"/tmp/test.txt"
        }
    )
)


print("="*60)
print("SENSITIVE TOOL")
print("="*60)

print(
    gateway.intercept_tool_call(
        "copilot",
        "delete_file",
        {
            "path":"/tmp/test.txt"
        }
    )
)


print("="*60)
print("AUDIT")
print("="*60)

for e in gateway.audit_log:
    print(e)