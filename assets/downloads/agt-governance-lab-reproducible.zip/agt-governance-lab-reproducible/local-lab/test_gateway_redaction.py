from agent_os.mcp_gateway import MCPGateway
from agent_os.integrations.base import GovernancePolicy
from agent_os.mcp_protocols import InMemoryAuditSink


sink = InMemoryAuditSink()

policy = GovernancePolicy(
    name="redaction-test"
)

gateway = MCPGateway(
    policy,
    audit_sink=sink
)


gateway.intercept_tool_call(
    "copilot",
    "read_file",
    {
        "path": "/tmp/test.txt",
        "password": "SuperSecret123",
        "token": "eyJhbGciOiJIUzI1NiJ9.test.payload"
    }
)


print("AUDIT:")
for event in sink.entries():
    print(event)