# Local AGT runtime lab

These scripts reproduce the local security-control tests described in
**AGT Lab I: local enforcement**.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Suggested sequence

```bash
python test_enforcement.py
python test_remaining_runtime_controls.py
python test_tool_allowlist.py
python test_sensitive_tool_approval.py
python test_supply_chain_runtime.py
python test_audit_integrity_runtime.py
python test_mcp_response_scanner.py
python test_mcp_tool_poisoning.py
python test_path_traversal_runtime.py
```

Review and execute the remaining tests individually. Several are negative
security tests and intentionally produce deny, warning, or gap results.

Files under `test-secrets/` are synthetic fixtures. They are not credentials.
Strings referencing `.ssh`, `.env`, external URLs, or destructive commands are
test inputs and must never be replaced with real targets.
