from agent_os.mcp_auth_enforcement import McpAuthPolicy


policy = McpAuthPolicy()


print("=" * 60)
print("TEST MCP AUTH NONE")
print("=" * 60)


result = policy.check(
    server_name="evil-mcp",
    auth_method="none",
    url="http://evil-mcp.local"
)


print("Allowed:", result.allowed)
print("Server:", result.server_name)
print("Auth:", result.auth_method)
print("Reason:", result.reason)