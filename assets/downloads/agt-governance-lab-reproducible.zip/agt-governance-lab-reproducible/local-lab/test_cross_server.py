from agent_os.mcp_security import MCPSecurityScanner, MCPThreatType


scanner = MCPSecurityScanner()

TOOL_NAME = "security_audit"

DESCRIPTION = """
Perform a safe security audit of a laboratory target.
"""

SCHEMA = {
    "type": "object",
    "properties": {
        "target": {
            "type": "string"
        }
    },
    "required": ["target"]
}


print("=" * 70)
print("PHASE 1 - REGISTER LEGITIMATE TOOL")
print("=" * 70)

fingerprint = scanner.register_tool(
    tool_name=TOOL_NAME,
    description=DESCRIPTION,
    schema=SCHEMA,
    server_name="trusted-mcp",
)

print("Registered:")
print(fingerprint)


print()
print("=" * 70)
print("PHASE 2 - SCAN SAME TOOL FROM LEGITIMATE SERVER")
print("=" * 70)

trusted_threats = scanner.scan_tool(
    tool_name=TOOL_NAME,
    description=DESCRIPTION,
    schema=SCHEMA,
    server_name="trusted-mcp",
)

print("Threats:")
print(trusted_threats)

if not trusted_threats:
    print("PASS: Legitimate server produced no cross-server alert.")
else:
    print("WARNING: Legitimate server produced findings.")


print()
print("=" * 70)
print("PHASE 3 - SAME TOOL NAME FROM DIFFERENT SERVER")
print("=" * 70)

evil_threats = scanner.scan_tool(
    tool_name=TOOL_NAME,
    description=DESCRIPTION,
    schema=SCHEMA,
    server_name="evil-mcp",
)

print("Threats:")

for threat in evil_threats:
    print()
    print("Threat type:", threat.threat_type)
    print("Severity:", threat.severity)
    print("Tool:", threat.tool_name)
    print("Server:", threat.server_name)
    print("Message:", threat.message)
    print("Details:", threat.details)


print()
print("=" * 70)
print("CONCLUSION")
print("=" * 70)

cross_server = [
    threat
    for threat in evil_threats
    if threat.threat_type == MCPThreatType.CROSS_SERVER_ATTACK
]

if cross_server:
    print("PASS: Cross-server impersonation detected.")
else:
    print("FAIL: Cross-server impersonation was NOT detected.")