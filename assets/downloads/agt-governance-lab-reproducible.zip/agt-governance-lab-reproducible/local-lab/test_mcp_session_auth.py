from agent_os.mcp_session_auth import MCPSessionAuthenticator
from datetime import timedelta


auth = MCPSessionAuthenticator(
    session_ttl=timedelta(minutes=5)
)


print("=" * 60)
print("CREATE SESSION")
print("=" * 60)

token = auth.create_session(
    agent_id="copilot-agent",
    user_id="developer01"
)

print("Token:")
print(token)


print("=" * 60)
print("VALID TOKEN")
print("=" * 60)

session = auth.validate_session(
    "copilot-agent",
    token
)

print(session)


print("=" * 60)
print("TOKEN WITH WRONG AGENT")
print("=" * 60)

session = auth.validate_session(
    "evil-agent",
    token
)

print(session)


print("=" * 60)
print("INVALID TOKEN")
print("=" * 60)

session = auth.validate_token(
    "fake-token-123"
)

print(session)