"""Protocol-level validation of the AGT MCP server over stdio."""

from __future__ import annotations

import asyncio
from pathlib import Path

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client


LAB_DIR = Path(__file__).resolve().parent
PYTHON = LAB_DIR.parent / ".venv" / "bin" / "python"
SERVER = LAB_DIR / "server.py"


async def main() -> None:
    params = StdioServerParameters(
        command=str(PYTHON),
        args=[str(SERVER)],
        cwd=str(LAB_DIR.parent),
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            tools = await session.list_tools()
            print("TOOLS:", [tool.name for tool in tools.tools])

            safe = await session.call_tool(
                "agt_safe_operation", {"message": "copilot-e2e-test"}
            )
            print("SAFE:", safe.content)

            safe_shell = await session.call_tool(
                "agt_shell_exec_simulation",
                {"command": "echo hello"},
            )
            print("SAFE_SHELL_SIMULATION:", safe_shell.content)

            denied = await session.call_tool(
                "agt_shell_exec_simulation",
                {"command": "rm -rf /tmp/agt-fake-target"},
            )
            print("DENIED:", denied.content)

            absolute_denied = await session.call_tool(
                "agt_shell_exec_simulation",
                {"command": "/bin/rm -rf /tmp/agt-fake-target"},
            )
            print("ABSOLUTE_PATH_DENIED:", absolute_denied.content)

            chained_denied = await session.call_tool(
                "agt_shell_exec_simulation",
                {"command": "echo hello; rm -rf /tmp/agt-fake-target"},
            )
            print("CHAINED_COMMAND_DENIED:", chained_denied.content)

            evidence = await session.call_tool("agt_get_evidence", {})
            print("EVIDENCE:", evidence.content)

            safe_text = str(safe.content)
            safe_shell_text = str(safe_shell.content)
            denied_text = str(denied.content)
            absolute_denied_text = str(absolute_denied.content)
            chained_denied_text = str(chained_denied.content)
            evidence_text = str(evidence.content)
            assert "ACS_ALLOWED" in safe_text
            assert "ACS_ALLOWED" in safe_shell_text
            assert "ACS_DENIED" in denied_text
            assert "reason=command_not_allowlisted" in denied_text
            assert "tool implementation executed=False" in denied_text
            assert "ACS_DENIED" in absolute_denied_text
            assert "reason=command_not_allowlisted" in absolute_denied_text
            assert "tool implementation executed=False" in absolute_denied_text
            assert "ACS_DENIED" in chained_denied_text
            assert "reason=command_not_allowlisted" in chained_denied_text
            assert "tool implementation executed=False" in chained_denied_text
            assert '\"tool_name\": \"agt_safe_operation\"' in evidence_text
            assert '\"tool_name\": \"agt_shell_exec_simulation\"' in evidence_text
            print("ASSERTIONS: PASS")


if __name__ == "__main__":
    asyncio.run(main())
