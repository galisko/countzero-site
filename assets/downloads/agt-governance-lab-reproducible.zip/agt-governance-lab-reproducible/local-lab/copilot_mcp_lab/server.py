"""ACS-governed MCP server for the GitHub Copilot end-to-end PoC."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable
from uuid import uuid4

from agent_control_specification import AgentControl, AgentControlBlocked
from mcp.server.mcpserver.server import MCPServer


LAB_DIR = Path(__file__).resolve().parent
EVIDENCE_FILE = LAB_DIR / "governance-evidence.jsonl"
MANIFEST_FILE = LAB_DIR / "manifest.yaml"
AGENT_ID = "github-copilot-vscode-lab"

control = AgentControl.from_path(str(MANIFEST_FILE))
server = MCPServer(name="agt-copilot-lab", version="2.0.0")


def parameter_digest(parameters: dict[str, Any]) -> str:
    canonical = json.dumps(parameters, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def record(
    correlation_id: str,
    tool_name: str,
    decision: str,
    reason: str | None,
    executed: bool,
    parameters: dict[str, Any],
) -> None:
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "correlation_id": correlation_id,
        "agent_id": AGENT_ID,
        "tool_name": tool_name,
        "decision": decision,
        "reason": reason,
        "executed": executed,
        "parameter_keys": sorted(parameters),
        "parameter_digest": parameter_digest(parameters),
    }
    with EVIDENCE_FILE.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(event, sort_keys=True) + "\n")


async def governed_call(
    tool_name: str,
    parameters: dict[str, Any],
    execute: Callable[[dict[str, Any]], Awaitable[str]],
) -> str:
    correlation_id = str(uuid4())
    executed = False

    async def tracked_execute(args: dict[str, Any]) -> str:
        nonlocal executed
        executed = True
        return await execute(args)

    try:
        result = await control.run_tool(tool_name, parameters, tracked_execute)
        verdict = result.pre_tool_call_result.verdict
        record(correlation_id, tool_name, verdict.decision.value, verdict.reason, executed, parameters)
        return f"ACS_ALLOWED correlation_id={correlation_id}: {result.value}"
    except AgentControlBlocked as error:
        verdict = error.result.verdict
        record(correlation_id, tool_name, verdict.decision.value, verdict.reason, executed, parameters)
        return (
            f"ACS_DENIED correlation_id={correlation_id}: "
            f"reason={verdict.reason}; tool implementation executed={executed}"
        )


async def safe_operation_impl(args: dict[str, Any]) -> str:
    return f"safe operation completed; message={args['message']!r}"


async def shell_simulation_impl(args: dict[str, Any]) -> str:
    return f"simulation only; operating-system command was not executed: {args['command']!r}"


async def evidence_impl(_: dict[str, Any]) -> str:
    if not EVIDENCE_FILE.exists():
        return "No evidence recorded yet."
    redacted_events = []
    for line in EVIDENCE_FILE.read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if "correlation_id" in event and "parameter_digest" in event:
            redacted_events.append(json.dumps(event, sort_keys=True))
    if not redacted_events:
        return "No ACS v2 evidence recorded yet."
    return "\n".join(redacted_events[-10:])


@server.tool()
async def agt_safe_operation(message: str = "hello") -> str:
    """Run a harmless operation through the ACS pre/post tool-call decisions."""
    return await governed_call("agt_safe_operation", {"message": message}, safe_operation_impl)


@server.tool()
async def agt_shell_exec_simulation(command: str = "rm -rf /tmp/agt-fake-target") -> str:
    """Request a simulated shell operation; ACS should deny before implementation."""
    return await governed_call(
        "agt_shell_exec_simulation", {"command": command}, shell_simulation_impl
    )


@server.tool()
async def agt_get_evidence() -> str:
    """Return recent redacted, correlation-ID-bearing ACS decisions."""
    return await governed_call("agt_get_evidence", {}, evidence_impl)


if __name__ == "__main__":
    server.run("stdio")
