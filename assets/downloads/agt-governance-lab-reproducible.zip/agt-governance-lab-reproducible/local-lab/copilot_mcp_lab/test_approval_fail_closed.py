import asyncio
from pathlib import Path

from agent_control_specification import AgentControl, AgentControlBlocked


executed = False


async def sensitive_operation(args):
    global executed
    executed = True
    return {"status": "completed", "ticket": args["ticket"]}


async def main():
    control = AgentControl.from_path(str(Path("copilot_mcp_lab/manifest.yaml").resolve()))
    try:
        await control.run_tool(
            "agt_sensitive_operation",
            {"ticket": "FAKE-APPROVAL-001"},
            sensitive_operation,
        )
    except AgentControlBlocked as error:
        print("POLICY_DECISION:", error.result.verdict.decision.value)
        print("POLICY_REASON:", error.result.verdict.reason)
        print("IMPLEMENTATION_EXECUTED:", executed)
        assert error.result.verdict.decision.value == "escalate"
        assert error.result.verdict.reason == "human_approval_required"
        assert executed is False
        print("ASSERTIONS: PASS")
        return
    raise AssertionError("Escalate without an approval resolver did not fail closed")


asyncio.run(main())
