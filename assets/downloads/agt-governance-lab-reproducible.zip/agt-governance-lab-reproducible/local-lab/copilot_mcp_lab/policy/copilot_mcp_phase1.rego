package copilot_mcp_phase1

import rego.v1

default verdict := {"decision": "allow"}

verdict := {
	"decision": "escalate",
	"reason": "human_approval_required",
	"message": "The sensitive operation requires explicit human approval.",
} if {
	input.intervention_point == "pre_tool_call"
	input.tool.name == "agt_sensitive_operation"
}

verdict := {
	"decision": "deny",
	"reason": "command_not_allowlisted",
	"message": "The simulated command is outside the strict echo allowlist.",
} if {
	input.intervention_point == "pre_tool_call"
	input.tool.name == "agt_shell_exec_simulation"
	args := object.get(input.policy_target, "value", {})
	command := lower(object.get(args, "command", ""))
	not regex.match(`^[[:space:]]*echo([[:space:]]+[a-z0-9._-]+)*[[:space:]]*$`, command)
}
