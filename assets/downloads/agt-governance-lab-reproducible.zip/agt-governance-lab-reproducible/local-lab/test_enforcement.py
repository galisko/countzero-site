from agentmesh.governance import govern, GovernanceDenied

def shell_exec(action: str, command: str):
    print(f"✅ TOOL EJECUTADA: action={action}, command={command}")
    return "EXECUTED"

safe_shell = govern(shell_exec, policy="policy.yaml")

# TEST 1 — Acción permitida
print("\n[TEST 1] Acción permitida")
try:
    safe_shell(action="safe_operation", command="echo SAFE")
    print("RESULTADO: ALLOW ✅")
except GovernanceDenied as e:
    print(f"RESULTADO: DENY ❌ {e}")

# TEST 2 — Acción bloqueada
print("\n[TEST 2] Acción prohibida")
try:
    safe_shell(action="shell_exec", command="echo BLOCKED")
    print("RESULTADO: ALLOW ❌")
except GovernanceDenied as e:
    print(f"RESULTADO: DENY ✅")
    print(f"AGT: {e}")

print("\n[AUDIT LOG]")
audit = safe_shell.audit_log

for entry in audit.query():
    print(
        f"event={entry.event_type} "
        f"action={entry.action} "
        f"outcome={entry.outcome} "
        f"policy={entry.policy_decision}"
    )

valid, error = audit.verify_integrity()
print(f"\nMerkle integrity: {valid}")
if error:
    print(f"Integrity error: {error}")
