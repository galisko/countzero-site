from agentmesh.governance.audit import AuditLog


audit = AuditLog()
entry = audit.log(
    event_type="policy_evaluation",
    agent_did="copilot",
    action="read_file",
    data={"path": "fake.txt"},
    outcome="allow",
    policy_decision="allow",
)

print("=" * 72)
print("TEST 14 - AUDIT MERKLE INTEGRITY")
print("=" * 72)
print(f"BEFORE TAMPER: {audit.verify_integrity()}")
entry.action = "tampered_action"
print(f"AFTER TAMPER:  {audit.verify_integrity()}")
