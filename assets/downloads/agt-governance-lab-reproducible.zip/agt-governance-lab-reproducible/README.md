# AGT Governance Lab — reproducible package

Sanitized companion package for the Count Zero AGT research and lab series.
It contains the executable material used to evaluate local runtime controls and
a repository-scoped governed MCP path.

## Contents

- `local-lab/` — controlled tests for policy allow/deny, approval, command
  patterns, budgets, tool integrity, MCP security, authentication, response
  scanning, audit integrity, redaction, path boundaries, and supply chain.
- `cloud-mcp/` — portable ACS-governed MCP server, canonical manifest, pinned
  dependencies, protocol smoke test, VS Code bootstrap, and repository cloud
  configuration.

## Safety

This is a security laboratory, not production software.

- All secrets and destructive operations are synthetic or simulated.
- Never replace the fixtures with real credentials or production data.
- Review every script before execution.
- Run in a disposable virtual environment and an isolated workspace.
- The package demonstrates that AGT governs instrumented paths. It is not a
  filesystem sandbox, DLP product, endpoint control, or egress firewall.

## Requirements

- Python 3.11 or newer.
- A disposable test directory.
- The pinned packages listed in each lab's `requirements.txt`.

## Local runtime lab

```bash
cd local-lab
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python test_remaining_runtime_controls.py
python test_supply_chain_runtime.py
python test_audit_integrity_runtime.py
```

The remaining `test_*.py` files are intentionally independent. Run them one at
a time and compare the policy verdict with the observed side effect.

## Repository cloud MCP lab

```bash
cd cloud-mcp
python3 scripts/bootstrap_vscode.py
```

The bootstrap creates a local environment, generates machine-specific MCP
configuration, validates the manifest, discovers tools through real MCP stdio,
and executes one allow and one deny case.

To run only the protocol test after installation:

```bash
.venv/bin/python scripts/smoke_test.py
```

## Evidence rule

A running server or discovered tool list is not end-to-end proof. Require both:

1. the client response containing an ACS result and correlation ID; and
2. a matching minimized audit event with the expected decision and `executed`
   state.

## Tested snapshot

- `agent-governance-toolkit-core==4.1.0`
- `agent-control-specification==0.3.1b1`
- `mcp==2.0.0`

Upstream APIs may have changed. Treat this package as an empirical snapshot and
revalidate every control before applying a result to a later release.

## Privacy and packaging

The distribution excludes Git history, virtual environments, generated logs,
JSONL evidence, caches, machine-specific MCP configuration, and personal paths.
The placeholder macOS account used in absolute-path negative tests is `nowi`.
