# AGT Copilot Cloud Lab

Reproducible laboratory for evaluating GitHub Copilot cloud agent with
an Agent Control Specification (ACS) governed local MCP service.

## Safety boundaries

- Use fictitious data and disposable fixtures only.
- Do not store credentials, tokens, personal data, or production configuration.
- Tool implementations must be simulations until explicitly reviewed.
- A denied ACS decision must be recorded as `executed: false`.
- Cloud-agent results require a correlated policy evidence event.

## Target flow

```text
GitHub Copilot cloud agent -> local stdio MCP -> AgentControl/ACS -> simulated tool
```

The broader local runtime tests are included in the sibling `local-lab/`
directory of the distribution package.

## Quick start

```bash
python3 scripts/bootstrap_vscode.py
```

The bootstrap creates a repository-local virtual environment, installs pinned
dependencies, generates machine-specific VS Code MCP configuration, validates
the manifest, discovers tools through MCP stdio, and executes one allow and one
deny case.

## Enabled tools

- `agt_cloud_safe_operation`: allowed and simulated.
- `agt_cloud_shell_simulation`: denied before its implementation runs.
- `agt_cloud_get_evidence`: returns recent redacted decisions.
