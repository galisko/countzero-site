"""Protocol smoke test for the repository-local governed MCP server."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

from agent_control_specification.validation import validate_acs_manifest
from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client


ROOT = Path(__file__).resolve().parent.parent


async def run() -> None:
    report = validate_acs_manifest((ROOT / "acs.manifest.yaml").read_text())
    print(f"MANIFEST_VALID: {report.valid}")
    if not report.valid:
        raise RuntimeError(report.diagnostics)

    parameters = StdioServerParameters(
        command=sys.executable,
        args=[str(ROOT / "server.py")],
        cwd=str(ROOT),
    )
    async with stdio_client(parameters) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            tools = await session.list_tools()
            names = [tool.name for tool in tools.tools]
            print(f"TOOLS: {names}")

            allowed = await session.call_tool(
                "agt_cloud_safe_operation", {"message": "vscode-bootstrap-smoke"}
            )
            denied = await session.call_tool(
                "agt_cloud_shell_simulation", {"command": "rm -rf /tmp/fake"}
            )
            allowed_text = str(allowed.content)
            denied_text = str(denied.content)
            print(f"ALLOW_RESULT: {allowed_text}")
            print(f"DENY_RESULT: {denied_text}")
            assert "ACS_ALLOWED" in allowed_text
            assert "ACS_DENIED" in denied_text
            assert "executed=False" in denied_text
            print("SMOKE_TEST: PASS")


if __name__ == "__main__":
    asyncio.run(run())
