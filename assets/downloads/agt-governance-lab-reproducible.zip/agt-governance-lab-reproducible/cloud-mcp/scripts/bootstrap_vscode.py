"""Create a repository-local runtime and VS Code MCP configuration."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import venv
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
VSCODE = ROOT / ".vscode"
MCP_CONFIG = VSCODE / "mcp.json"


def ensure_supported_python() -> None:
    if sys.version_info >= (3, 11):
        return

    for name in ("python3.14", "python3.13", "python3.12", "python3.11"):
        candidate = shutil.which(name)
        if candidate:
            print(
                f"PYTHON_REEXEC: {sys.version_info.major}.{sys.version_info.minor} "
                f"-> {candidate}"
            )
            os.execv(candidate, [candidate, str(Path(__file__).resolve())])

    raise SystemExit(
        "Python 3.11 or newer is required. Install an approved Python runtime "
        "and run this bootstrap again."
    )


def venv_python() -> Path:
    if sys.platform == "win32":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def main() -> None:
    ensure_supported_python()
    print(f"BOOTSTRAP_ROOT: {ROOT}")
    if not VENV.exists():
        print("CREATE_VENV: start")
        venv.EnvBuilder(with_pip=True).create(VENV)
        print("CREATE_VENV: complete")
    else:
        print("CREATE_VENV: existing")

    python = venv_python().resolve()
    subprocess.run(
        [
            str(python),
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "-r",
            str(ROOT / "requirements.txt"),
        ],
        check=True,
    )

    config = {
        "servers": {
            "agt-corporate-governance": {
                "type": "stdio",
                "command": str(python),
                "args": [str((ROOT / "server.py").resolve())],
                "sandboxEnabled": True,
            }
        },
        "sandbox": {
            "filesystem": {"allowWrite": ["${workspaceFolder}"]},
            "network": {
                "allowedDomains": [],
                "deniedDomains": ["registry.npmjs.org"],
            },
        },
    }
    VSCODE.mkdir(exist_ok=True)
    MCP_CONFIG.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    print(f"MCP_CONFIG: {MCP_CONFIG}")

    subprocess.run([str(python), str(ROOT / "scripts" / "smoke_test.py")], check=True)
    print("BOOTSTRAP_RESULT: PASS")


if __name__ == "__main__":
    main()
