"""Minimal ACS-governed MCP server for GitHub Copilot cloud agent."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable, Mapping
from uuid import uuid4

from agent_control_specification import AgentControl, AgentControlBlocked
from mcp.server.mcpserver.server import MCPServer


ROOT = Path(__file__).resolve().parent
EVIDENCE_FILE = ROOT / "governance-evidence.jsonl"


class CloudPolicyDispatcher:
    """Host policy used to isolate the cloud transport test from OPA setup."""

    def evaluate(self, invocation: Mapping[str, Any]) -> Mapping[str, Any]:
        policy_input = invocation.get("input", {})
        if (
            policy_input.get("intervention_point") == "pre_tool_call"
            and policy_input.get("tool", {}).get("name")
            == "agt_cloud_shell_simulation"
        ):
            return {
                "decision": "deny",
                "reason": "cloud_shell_simulation_blocked",
                "message": "The cloud shell simulation is denied by ACS.",
            }
        return {"decision": "allow"}


control = AgentControl.from_path(
    str(ROOT / "acs.manifest.yaml"),
    policy_dispatcher=CloudPolicyDispatcher(),
)
server = MCPServer(name="agt-copilot-cloud-lab", version="1.0.0")


def digest(parameters: dict[str, Any]) -> str:
    value = json.dumps(parameters, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(value.encode()).hexdigest()


def record(correlation_id: str, tool: str, decision: str, reason: str | None, executed: bool, parameters: dict[str, Any]) -> None:
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "correlation_id": correlation_id,
        "tool_name": tool,
        "decision": decision,
        "reason": reason,
        "executed": executed,
        "parameter_keys": sorted(parameters),
        "parameter_digest": digest(parameters),
    }
    with EVIDENCE_FILE.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(event, sort_keys=True) + "\n")


async def governed(tool: str, parameters: dict[str, Any], execute: Callable[[dict[str, Any]], Awaitable[str]]) -> str:
    correlation_id = str(uuid4())
    executed = False

    async def tracked(args: dict[str, Any]) -> str:
        nonlocal executed
        executed = True
        return await execute(args)

    try:
        result = await control.run_tool(tool, parameters, tracked)
        verdict = result.pre_tool_call_result.verdict
        record(correlation_id, tool, verdict.decision.value, verdict.reason, executed, parameters)
        return f"ACS_ALLOWED correlation_id={correlation_id}: {result.value}"
    except AgentControlBlocked as error:
        verdict = error.result.verdict
        record(correlation_id, tool, verdict.decision.value, verdict.reason, executed, parameters)
        return f"ACS_DENIED correlation_id={correlation_id}: reason={verdict.reason}; executed={executed}"


@server.tool()
async def agt_cloud_safe_operation(message: str = "cloud-test") -> str:
    """Run a harmless simulated cloud operation through ACS."""

    async def execute(args: dict[str, Any]) -> str:
        return f"cloud safe operation completed; message={args['message']!r}"

    return await governed("agt_cloud_safe_operation", {"message": message}, execute)


@server.tool()
async def agt_cloud_shell_simulation(command: str = "rm -rf /tmp/fake") -> str:
    """Submit a simulated shell operation that ACS must deny before execution."""

    async def execute(args: dict[str, Any]) -> str:
        return f"simulation only: {args['command']!r}"

    return await governed("agt_cloud_shell_simulation", {"command": command}, execute)


@server.tool()
async def agt_cloud_get_evidence() -> str:
    """Return recent redacted ACS decisions from the current cloud session."""

    async def execute(_: dict[str, Any]) -> str:
        if not EVIDENCE_FILE.exists():
            return "No evidence recorded yet."
        return "\n".join(EVIDENCE_FILE.read_text(encoding="utf-8").splitlines()[-10:])

    return await governed("agt_cloud_get_evidence", {}, execute)


if __name__ == "__main__":
    server.run("stdio")
