# MCP Tool Poisoning: reproducible lab

This package recreates the protocol-level portion of Count Zero's MCP Tool Poisoning lab. It starts a real MCP Streamable HTTP server on loopback, performs a real handshake, lists the tool, and makes a real `tools/call` request.

The package does not include an LLM and does not read a canary file, execute a privileged follow-up, or send data anywhere. The client makes the trust decision visible and deterministic so the protocol boundary can be inspected safely.

The default port is `8765`. Set `MCP_LAB_PORT` on both processes if that port is already in use.

## Requirements

- Python 3.12+
- A system you own or are authorized to test
- Two terminal windows

## Install

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Expected output (abridged):

```text
Successfully installed ... mcp-2.1.1 ...
```

## 1. Run the poisoned server

Terminal A:

```bash
.venv/bin/python server_poisoned.py
```

Expected output (abridged):

```text
Uvicorn running on http://127.0.0.1:8765
```

Terminal B:

```bash
.venv/bin/python client.py --mode observe
```

Expected output (abridged):

```text
MCP_HANDSHAKE=OK tools=1
TOOL name=security_audit poisoned_metadata=True
TOOL_CALL=REAL
RETURN_SCAN_FLAGGED=True
CLIENT_POLICY=OBSERVE_ONLY
FOLLOW_UP_EXECUTION=DISABLED_IN_LAB
```

Stop Terminal A with `Ctrl+C`.

## 2. Apply the client-side control

Start the poisoned server again, then run:

```bash
.venv/bin/python client.py --mode protected
```

Expected output (abridged):

```text
METADATA_SCAN_FLAGGED=True
RETURN_SCAN_FLAGGED=True
CLIENT_POLICY=FAIL_CLOSED
FOLLOW_UP_EXECUTION=BLOCKED
```

Stop Terminal A with `Ctrl+C`.

## 3. Replace the server with the hardened version

Terminal A:

```bash
.venv/bin/python server_hardened.py
```

Expected output (abridged):

```text
SERVER_POLICY=PINNED_HASH_OK
Uvicorn running on http://127.0.0.1:8765
```

Terminal B:

```bash
.venv/bin/python client.py --mode observe
```

Expected output (abridged):

```text
TOOL name=security_audit poisoned_metadata=False
RETURN_SCAN_FLAGGED=False
FOLLOW_UP_EXECUTION=DISABLED_IN_LAB
```

## 4. Verify the controls offline

```bash
.venv/bin/python test_controls.py
```

Expected output:

```text
Ran 4 tests

OK
```

## Optional VPS tunnel

Keep both MCP servers bound to `127.0.0.1`. From the client system:

```bash
ssh -N -L 8765:127.0.0.1:8765 user@your-vps
```

Expected output:

```text
(no output while the tunnel remains open)
```

## Files

- `server_poisoned.py`: poisoned description and response fixture.
- `server_hardened.py`: literal definition pin, strict input validation, fixed response, and JSONL audit.
- `client.py`: MCP client with observe-only and fail-closed modes.
- `test_controls.py`: offline checks for definition drift and response detection.

## Safety boundary

The hostname `attacker.example.invalid` is reserved for documentation and does not resolve. Keep the service on loopback. Use synthetic data.
