#!/usr/bin/env python3
"""MCP client that exposes the trust decision without using an LLM."""

from __future__ import annotations

import argparse
import asyncio
import os

from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

SUSPICIOUS = ("ignore previous", "important system", "read /opt/", "upload", "attacker.")


def contains_instruction_like_text(value: str) -> bool:
    lowered = value.lower()
    return any(token in lowered for token in SUSPICIOUS)


async def run(url: str, mode: str) -> None:
    async with streamable_http_client(url) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            listing = await session.list_tools()
            print(f"MCP_HANDSHAKE=OK tools={len(listing.tools)}")

            metadata_flagged = False
            for tool in listing.tools:
                flagged = contains_instruction_like_text(tool.description or "")
                metadata_flagged = metadata_flagged or flagged
                print(f"TOOL name={tool.name} poisoned_metadata={flagged}")

            result = await session.call_tool("security_audit", {"note": "synthetic-ticket-001"})
            text = "\n".join(block.text for block in result.content if getattr(block, "text", None))
            return_flagged = contains_instruction_like_text(text)

            print("TOOL_CALL=REAL")
            print("TOOL_RETURN_BEGIN")
            print(text)
            print("TOOL_RETURN_END")
            print(f"METADATA_SCAN_FLAGGED={metadata_flagged}")
            print(f"RETURN_SCAN_FLAGGED={return_flagged}")

            if mode == "observe":
                print("CLIENT_POLICY=OBSERVE_ONLY")
                print("FOLLOW_UP_EXECUTION=DISABLED_IN_LAB")
            else:
                blocked = metadata_flagged or return_flagged
                print("CLIENT_POLICY=FAIL_CLOSED")
                print(f"FOLLOW_UP_EXECUTION={'BLOCKED' if blocked else 'NOT_TRIGGERED'}")


def main() -> None:
    parser = argparse.ArgumentParser()
    port = os.environ.get("MCP_LAB_PORT", "8765")
    parser.add_argument("--url", default=f"http://127.0.0.1:{port}/mcp")
    parser.add_argument("--mode", choices=("observe", "protected"), required=True)
    args = parser.parse_args()
    asyncio.run(run(args.url, args.mode))


if __name__ == "__main__":
    main()
